module.exports=[67084,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_tema_page_actions_0hgd67c.js.map