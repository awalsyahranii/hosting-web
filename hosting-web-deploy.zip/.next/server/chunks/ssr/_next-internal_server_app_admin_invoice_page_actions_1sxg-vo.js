module.exports=[95062,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_invoice_page_actions_1sxg-vo.js.map