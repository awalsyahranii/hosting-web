module.exports=[72746,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tema_page_actions_0-8tq33.js.map