module.exports=[60091,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_domain_page_actions_0bicd7a.js.map