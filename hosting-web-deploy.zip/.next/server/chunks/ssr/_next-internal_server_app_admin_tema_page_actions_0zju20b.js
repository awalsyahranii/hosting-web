module.exports=[60273,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_tema_page_actions_0zju20b.js.map