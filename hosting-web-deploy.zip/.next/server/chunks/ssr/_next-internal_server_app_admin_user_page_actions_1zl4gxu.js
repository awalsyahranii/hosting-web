module.exports=[82320,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_user_page_actions_1zl4gxu.js.map