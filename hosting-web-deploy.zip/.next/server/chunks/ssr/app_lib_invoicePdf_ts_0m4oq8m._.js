module.exports=[24395,a=>{"use strict";async function b(a){}a.i(57264),a.s(["printOrDownloadInvoicePdf",0,function(a){b(a)}],24395)}];

//# sourceMappingURL=app_lib_invoicePdf_ts_0m4oq8m._.js.map