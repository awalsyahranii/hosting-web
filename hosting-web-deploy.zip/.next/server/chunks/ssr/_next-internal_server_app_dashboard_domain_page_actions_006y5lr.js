module.exports=[58173,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_domain_page_actions_006y5lr.js.map