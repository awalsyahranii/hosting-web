module.exports=[85266,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_coupon_page_actions_1rmm84t.js.map