module.exports=[49733,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_security_page_actions_13g5v1a.js.map