module.exports=[68135,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_hosting_page_actions_0ge_sfy.js.map