module.exports=[99878,a=>{"use strict";a.s(["generateWhatsAppReminderUrl",0,function({clientName:a,domainName:b,serviceType:c="Hosting",expiryDate:d,daysRemaining:e,phone:f=""}){let g=f?f.replace(/[^0-9]/g,""):"",h=g.startsWith("0")?"62"+g.slice(1):g,i="";i=null!==e?e<0?`telah kedaluwarsa sejak *${Math.abs(e)} hari yang lalu*`:0===e?"akan *berakhir HARI INI*":`akan segera berakhir dalam *${e} hari lagi* (tanggal ${d})`:`akan berakhir pada *${d}*`;let j=`Halo Kak *${a}*,

Kami dari tim *HostingWeb.id* ingin menginformasikan bahwa layanan *${c}* untuk domain *${b}* ${i}.

Agar website dan email bisnis Anda tetap berjalan normal tanpa gangguan, silakan lakukan perpanjangan layanan melalui dashboard:
👉 https://hostingwebid.com/dashboard

Jika butuh bantuan faktur atau perpanjangan, silakan balas pesan ini ya Kak.

Terima kasih! 🙏✨`;return`https://wa.me/${h}?text=${encodeURIComponent(j)}`},"getExpiryInfo",0,function(a){if(!a||"-"===a||"Belum aktif"===a)return{daysRemaining:null,isExpiringSoon:!1,isExpired:!1,isCritical:!1,statusText:"Belum aktif",formattedDate:"Belum aktif"};let b=a;try{let c=new Date(a.replace(" ","T"));isNaN(c.getTime())||(b=new Intl.DateTimeFormat("id-ID",{day:"numeric",month:"long",year:"numeric"}).format(c))}catch{b=a}try{let c=new Date(a.replace(" ","T")).getTime();if(isNaN(c))return{daysRemaining:null,isExpiringSoon:!1,isExpired:!1,isCritical:!1,statusText:a,formattedDate:b};let d=new Date().getTime(),e=Math.ceil((c-d)/864e5);if(e<0){let a=Math.abs(e);return{daysRemaining:e,isExpiringSoon:!1,isExpired:!0,isCritical:!1,statusText:1===a?"Kedaluwarsa 1 hari lalu":`Kedaluwarsa ${a} hari lalu`,formattedDate:b}}if(0===e)return{daysRemaining:0,isExpiringSoon:!0,isExpired:!1,isCritical:!0,statusText:"Berakhir Hari Ini!",formattedDate:b};if(e<=7)return{daysRemaining:e,isExpiringSoon:!0,isExpired:!1,isCritical:e<=3,statusText:`Sisa ${e} Hari`,formattedDate:b};return{daysRemaining:e,isExpiringSoon:!1,isExpired:!1,isCritical:!1,statusText:`Sisa ${e} Hari`,formattedDate:b}}catch{return{daysRemaining:null,isExpiringSoon:!1,isExpired:!1,isCritical:!1,statusText:a,formattedDate:b}}}])}];

//# sourceMappingURL=app_lib_expiryHelper_ts_1l8a36q._.js.map