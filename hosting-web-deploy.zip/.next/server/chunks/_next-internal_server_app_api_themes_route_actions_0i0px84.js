module.exports=[65936,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_themes_route_actions_0i0px84.js.map