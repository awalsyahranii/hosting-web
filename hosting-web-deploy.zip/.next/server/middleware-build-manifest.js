globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/XEY1M6chQ1u1GRGrWsEKt/_buildManifest.js",
    "static/XEY1M6chQ1u1GRGrWsEKt/_ssgManifest.js",
    "static/XEY1M6chQ1u1GRGrWsEKt/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/310vm2bl3xxpt.js",
    "static/chunks/2mmpezlrfmbu5.js",
    "static/chunks/3e4keds9ktjdu.js",
    "static/chunks/2hbx0u5pc3csk.js",
    "static/chunks/turbopack-069nmt074whvj.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
