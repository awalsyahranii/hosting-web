var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/themes/route.js")
R.c("server/chunks/[externals]__1fe0svr._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_0k53kre._.js")
R.c("server/chunks/_next-internal_server_app_api_themes_route_actions_0i0px84.js")
R.m(90616)
module.exports=R.m(90616).exports
